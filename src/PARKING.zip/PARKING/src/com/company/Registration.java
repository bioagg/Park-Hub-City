package com.company;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

//h klasi auti einai otan patame login h sign in na emfanizetai ena deutero parathiro to opoio na mporoume
//na eisagoume to username kai password

public class Registration  implements  ActionListener{


    JFrame app = new JFrame();
    JPanel panel = new JPanel();
    JLabel userLabel = new JLabel("USER");
    JLabel passwordLabel = new JLabel("PASSWORD");
    JTextField usernameTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton submitButton = new JButton("SUBMIT");
    JLabel success = new JLabel();










    Registration(){

        app.setTitle("REGISTRATION");
        app.setSize(420, 420);
        app.setBackground(Color.black);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setResizable(true);
        app.setBackground(Color.black);
        app.setLayout(null);
        app.getContentPane().setLayout(null);


        userLabel.setBounds(10,20,80,25);
        userLabel.setOpaque(true);
        app.add(userLabel);

        passwordLabel.setBounds(10,50,80,25);
        passwordLabel.setOpaque(true);
       app.add(passwordLabel);

        usernameTextField.setBounds(100,20,165,25);
        usernameTextField.setHorizontalAlignment(usernameTextField.CENTER);
        usernameTextField.setBackground(Color.red);
        app.add(usernameTextField);

        passwordField.setBounds(100,50,165,25);
        passwordField.setBackground(Color.red);
        app.add(passwordField);

        submitButton.setBounds(10,80,80,25);
        submitButton.addActionListener(this);

        app.add(submitButton);

        success.setBounds(10,110,300,25);
        app.add(success);


        app.setVisible(true);






    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String user = usernameTextField.getText();
        String password = passwordField.getText();
        System.out.println(user + "," + password);

        app.setVisible(true);
        app.dispose();
       Menu menu = new Menu();

    }
}

