package com.company;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

//h klasi auti einai otan patame login h sign in na emfanizetai ena deutero parathiro to opoio na mporoume
//na eisagoume to username kai password

public class Registration  implements  ActionListener{


    JFrame app = new JFrame();
    JPanel panel = new JPanel();
    JLabel userLabel = new JLabel("USERNAME");
    JLabel passwordLabel = new JLabel("PASSWORD");
    JTextField usernameTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton submitButton = new JButton("SUBMIT");
    JLabel success = new JLabel();










    Registration(){


        app.setTitle("REGISTRATION");
        app.setSize(420, 420);
        app.setBackground(Color.black);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setResizable(true);
        app.setBackground(Color.black);
        app.setLayout(null);
        app.getContentPane().setLayout(null);


        userLabel.setBounds(600,360,80,25);
        userLabel.setOpaque(true);
        userLabel.setBackground(Color.red);
        app.add(userLabel);

        passwordLabel.setBounds(600,450,80,25);
        passwordLabel.setOpaque(true);
        passwordLabel.setBackground(Color.red);
        app.add(passwordLabel);

        usernameTextField.setBounds(600,380,165,25);
        usernameTextField.setHorizontalAlignment(usernameTextField.CENTER);
        usernameTextField.setBackground(Color.red);
        app.add(usernameTextField);

        passwordField.setBounds(600,470,165,25);
        passwordField.setHorizontalAlignment(passwordField.CENTER);
        passwordField.setBackground(Color.red);
        app.add(passwordField);

        submitButton.setBounds(600,510,80,25);
        submitButton.addActionListener(this);

        app.add(submitButton);

        success.setBounds(10,110,300,25);
        app.add(success);


        app.setVisible(true);






    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String user = usernameTextField.getText();
        String password = passwordField.getText();
        System.out.println(user + "," + password);

        app.setVisible(true);
        app.dispose();
        Menu menu = new Menu();

    }
}
